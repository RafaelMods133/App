module.exports = {
  Token: "7560609475:AAEX5ALGZcF5w5BR7nq50GgQKYz9yBkne0w",
  owner: "6498443469",
};